<?php
session_start();
?>
<?php include "header.php" ?>
<?php
require_once "../includes/dbh.inc.php";
$limit_per_page=3;
if(isset($_GET['page'])){
   $page=$_GET['page'];
}else{
	$page=1;
}
$offset=($page-1)*$limit_per_page;
$que="SELECT * FROM user ORDER BY user_id DESC LIMIT $offset,$limit_per_page";
$resl=mysqli_query($conn,$que) or die("query failed");

?>
<section class="table-wrapper">
<div class="postinsert__header">
    <h2 class="postinsert__title">all users</h2>
    <div class="postinsert__but"><a href="http://anjumanehefajoth.com/admin/add-user.php">add post</a> </div>
</div>
<table class="table">
     <thead>
     	 <th>S.No</th>
     	 <th>Frist-Name</th>
     	 <th>Last-name</th>
     	 <th>Username</th>
     	 <th>Password</th>
		  <th>role</th>
		  <th>edit</th>
		  <th>delete</th>
		  
     </thead>
     <tbody>
	      <?php 
			 while($row=mysqli_fetch_assoc($resl)){
			  ?>
     	  <tr>
     	  	  <td data-label="S.No"><?= $row['user_id']?></td>
     	  	  <td data-label="Frist-Name"><?= $row['first_name']?></td>
     	  	  <td data-label="last_name"><?= $row['last_name']?></td>
     	  	  <td data-label="username"><?=$row['username']?></td>
			  <td data-label="password"><?=$row['password']?></td> 
     	  	  <td data-label="role"><?php
				  if($row['role'] ==1){
					  echo "admin";
				  }else{
					  echo "normal user";
				  }
				 ?></td>
     	  	  <td data-label="Staus">
				 <a href="http://anjumanehefajoth.com/admin/edit-user.php?id=<?= $row['user_id']?>"><i class="fa fa-edit" aria-hidden="true"></i></a> 
			 </td>
			  <td data-label="Staus">
			  <a href="http://anjumanehefajoth.com/admin/delet-user.php?id=<?= $row['user_id']?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
				</td>
     	  </tr>
		   <?php
			    } 
			?>
     </tbody>
   </table>
   
</section>
<div class="paginatinon">
<?php 
$que="SELECT * FROM user";
$resl1=mysqli_query($conn,$que) or die("query failed");
$total_records=mysqli_num_rows($resl1);
$limit_per_page=3;
$total_pages=ceil($total_records/$limit_per_page);
for($i=1; $i <= $total_pages; $i++){
	if($i == $page){
		$active="active";
	}else{
		$active="";
	}
	echo '<div class=" btn btn1 p1 '.$active.'"> <a href="http://anjumanehefajoth.com/admin/all-users.php?page='.$i.'">'.$i.'</a></div>';
}
?>
</div>
<?php include "footer.php"; ?>
