
<div class="righside">
            <div class="search">
                <h4 class="search__title">এখানে খোঁজ করুন...</h4>
                <form class="fromcontrol" action="http://anjumanehefajoth.com/search.php" method="get">
                    <input type="search" placeholder="search" name="search" class="seachinp" >
                    <input type="submit" class="btn1" value="খুঁজুন">
                </form>
                
            </div>
 <?php
require_once 'includes/dbh.inc.php';
$sqlre="select * from post 
         left join category on post.category=category.category_id
         left join user on post.author=user.user_id 
         order by post_id desc
         limit 4";
        $resu=mysqli_query($conn,$sqlre) or die('query failed');       
        ?>
            <div class="recenpost">
                <h4 class="recenpost__title">RECEN POS</h4>
                <?php 
                while($ro=mysqli_fetch_assoc($resu)){
                    ?>
                  <div class="rpos">
                <div class="rpos__lefside">
                    <img src="images/<?=$ro['post_img']?> " alt="" class="pos__image">
                </div>
                <div class="rpos__righside">
                    <h4 class="pos__title paragraph"><?=substr($ro['title'],0,40).'...'?> </h4>
                    <div class="tagline">
                        <div class="category"><i class="fas fa-tags"></i><?=$ro['category_name']?></div>
                        <div class="date"><i class="fa fa-calendar" aria-hidden="true"></i><?=$ro['post_date']?></div>
                    </div>
                    <a href="http://anjumanehefajoth.com/single.php?id=<?=$ro['post_id']?>"><button class="recenpost__but btn">read more</button></a>
                </div>
               </div> 
                <?php    
                }
                ?>
                  
                <!-- == --> 
                
                <!-- == -->   
                
                <!-- == --> 
               
                <!-- == --> 
                          
            </div>
        </div>