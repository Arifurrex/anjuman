  
<?php
    @include '../admin/starheader.php';
    @include '../admin/starnavigation.php';
    @include '../admin/starsidenavbar.php';
    @include '../admin/starmain.php';
    @include '../admin/startscript.php';
?>
   