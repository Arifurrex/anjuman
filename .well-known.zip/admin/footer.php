<footer id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2020 News | Powered by <a href="https://alinessaitsolution.netlify.app/">alinessa</a></span>
            </div>
        </div>
    </div>
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="../src/1-scripts/script.js"></script>
<script src="../src/1-scripts/jquery-3.5.1.min.js"></script>

</body>
</html>

