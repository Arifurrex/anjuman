<?php
$host='localhost';
$user='anjumane_anjumane';
$password='t;kUqRMI[_1t';
$database='anjumane_anjoman';
$conn=mysqli_connect($host,$user,$password,$database);
$conn->set_charset("utf8");
if(!$conn){
    die("connec failed :" . mysqli_connect_error());
}
