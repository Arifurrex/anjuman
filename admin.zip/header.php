
<!DOCTYPE html>
<html lang="bn">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.maateen.me/charukola-ultra-light/font.css" rel="stylesheet">
    <link href="https://fonts.maateen.me/kalpurush/font.css" rel="stylesheet">

    <link rel="stylesheet" href="css/normalize.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
    <link rel="stylesheet" href="src/owl.carousel.min.css" />
    <link rel="stylesheet" href="src/superslides.css" />
    <link rel="stylesheet" href="src/2-styles/main.css" />
    <title>আঞ্জুমান হেফাযত বাংলাদেশ </title>
  </head>
  <body>
    <!-- ============================ -->
    <!-- header start from here  -->
    <!-- ============================ -->
    <marquee width="80%" direction="left" height="50px" margin="0 auto">
     <h1>work on proceess....</h1>
    </marquee>
    <header>
         <!-- <a href="http://localhost:3000/index.php" class="logo-image logohide">
            <img src="images/Only Logo.bmp" alt="logo-light" /> 
         </a> -->
      <nav>
         <a href="http://anjumanehefajoth.com/index.php" class="logo-image logohide2">
            <img src="images/Only Logo.bmp" alt="logo-light" /> 
         </a>
         <a href="http://anjumanehefajoth.com" class="logo-image logohide">
           আঞ্জুমান হেফাযত
         </a>
        <ul class="nav-list">
        <!--<li class="nav-list-item ">-->
        <!--  <a class="" href="http://anjumanehefajoth.com/" class="black nav-links"-->
        <!--    >মূলপাতা</a-->
        <!--  >-->
        <!--</li>-->
        <?php
include 'includes/dbh.inc.php';
$sql="select * from category where post > 0";
$res=mysqli_query($conn,$sql) or die('query failed');
?>
        <?php
        while($row=mysqli_fetch_assoc($res)){ 
          
          if(isset($_GET['catid'])){
               if($row['category_id']==$_GET['catid']){
                 $active="active";
               }else{
                 $active="";
               }
          }else{
            $active="";
          }
          ?>
         
          <li class="nav-list-item ">
          <a class="<?=$active?>" href="http://anjumanehefajoth.com/category.php?catid=<?=$row['category_id']?>" class="black nav-links"
            ><?= $row['category_name']?></a
          >
        </li>
        <?php
        }
        ?>
        </ul>
        <div class="menu-btn">
          <div class="menu-btn__burger"></div>
        </div>
        <div class="mobile-white-background"></div>
        <div class="mobile-nav-block">
          <ul class="mobile-nav-list">
          <?php
          while($row=mysqli_fetch_assoc($res)){?>
            <li class="mobile-nav-list-item">
              <a href="/src/3-pages/aboutus.html" class="nav-links-mobile"
                >ggf</a
              >
            </li>
            <?php
          }
          ?>
            <li class="mobile-nav-list-item">
              <a href="/src/3-pages/aboutus.html" class="nav-links-mobile"
                >ggf</a
              >
            </li>
            
           
          </ul>
        </div>
      </nav>
    </header>
    <!-- ============================ -->
    <!-- header end from here  -->
    <!-- ============================ -->
