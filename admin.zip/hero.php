<?php
include 'bnTime.php';
function BDdate($time)
{
$bn = new BanglaDate($time);
 $output = $bn->get_date();
 $ReadyDate = "$output[0] $output[1] $output[2]";
 return $ReadyDate;
}
$time = time();
$Bdate = BDdate($time);
// echo $Bdate;
?>
    <section class="hero-section">
      <!-- === -->
      <div class="slider" id="slides">
        <div class="slides-container">
          <img src="images/beautiful-bangladesh.jpg" alt="" />
          <img src="images/mustrad-flower.jpg" alt="" />
          <img src="images/003.jpg" alt="" />
        </div>
      </div>
      
      <!-- === -->
      <div class="glass-container">
        <div class="glass-date owl-carousel owl-theme">
          <p class="glass-date__item">আজ <?php setlocale(LC_ALL, 'bn_BD');
                   echo strftime("%A - %e %B %Y"); ?> ইং</p>
          <p class="glass-date__item"><?php echo $Bdate;?> বঙ্গাব্দ</p>
          <!-- <p class="glass-date__item">২২ শে জামাদিওস সামি ,১৪৪২ হিজরি</p> -->
        </div>
        <div class="glass-card">
          <!-- <div class="left-side"></div> -->
          <div class="right-side">
            <div class="right-side-header">
              <!-- <h3 class="right-side-header__title">active status</h3> -->
              <div class="search">
                <form class="search-tag-wrapper" action="http://anjumanehefajoth.com/search.php" method="get">
                  <input type="search" placeholder="এখানে খোঁজ করুন ..." name="search"/>
                  <button class="search__button" type="submit">
                    খুঁজুন
                    <!-- <i class="fas fa-search"></i> -->
                  </button>
                </form>
              </div>
            </div>
            <!-- === -->

            <!-- ==== -->
            <div class="counter-wraper">
              <div class="counterr">
                <div class="counter__icon">
                  <i class="fas fa-user"></i>
                </div>
                <div class="statsSection">
                  <div class="number-count counter">121212</div>
                </div>
                <div class="counter__name">সদস্য</div>
              </div>
              <div class="counterr">
                <div class="counter__icon">
                  <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="number-count counter">64</div>
                <div class="counter__name">স্থান</div>
              </div>
              <div class="counterr">
                <div class="counter__icon">
                  <i class="fa fa-fire"></i>
                </div>
                <div class="number-count counter">98</div>
                <div class="counter__name">তথ্য</div>
              </div>
              <div class="counterr">
                <div class="counter__icon">
                  <i class="fas fa-question"></i>
                </div>
                <div class="number-count counter">598</div>
                <div class="counter__name">প্রশ্ন</div>
              </div>
            </div>
            <!-- === -->
            <div class="eventMessage">
              <i class="far fa-calendar-alt"></i>
              <p class="sub typed"></p>
            </div>
            <!-- == -->
          </div>
        </div>
      </div>
    </section>

