<?php
session_start();
session_unset();
session_destroy();
header('location:http://anjumanehefajoth.com/admin?sucess=logout');
exit();