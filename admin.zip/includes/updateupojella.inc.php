<?php
require_once '../includes/dbh.inc.php';
$ca=$_POST['upojella_name'];
$id=$_GET['id'];
$sqli="UPDATE `upojella` SET `upojella_name`= '$ca' WHERE upojella_id='$id'";
$result=mysqli_query($conn,$sqli) or die('query failed');
header('location:http://anjumanehefajoth.com/admin/upojella.php?msg=updasuccess!!');
exit();
 