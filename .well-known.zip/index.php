
<?php
include 'header.php'; 
include 'hero.php';
include 'includes/dbh.inc.php';
include 'news.php';
// include 'testomonial.php';
include 'CustomerUI.php';
include 'footer.php'; 
?>

