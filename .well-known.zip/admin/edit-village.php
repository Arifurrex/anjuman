<?php
session_start();
if($_SESSION["role"]==0){
	header('location:http://anjumanehefajoth.com/admin?error=loginfirs');
	exit();
}
?>
<?php include "header.php"; ?>
<?php
   require_once '../includes/dbh.inc.php';
   $id=$_GET['id'];
   $sqli="select * from village where village_id='$id'";
   $result=mysqli_query($conn,$sqli) or die('query failed');
   $row=mysqli_fetch_assoc($result);
?>
  <div class="admin-content">        
  <div class="contact__form">    
        <form action="../includes/updatevillage.inc.php?id=<?= $row['village_id'] ?>" method="post" autocomplete="off">
             <div class="add-user-header">
                 <h4 class="admin-heading">Edit village</h4>
             </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="village_name" name="village_name" value="<?= $row['village_name'] ?>"/>
          </div>
          <!-- <div class="from-control paragraph">
            <select name="role" id="" value="" required>
            <option selected value="" disabled></option>
            <option value="1">admin</option>
            <option value="2">normal user</option>
            </select>
          </div> -->
           <div class="from-control">
            <input type="submit" value="Update village" name="submit" class="btn" />
          </div>
        </form>
   </div>
  <!--/Form -->
 
          
  </div>
<?php include "footer.php"; ?>

