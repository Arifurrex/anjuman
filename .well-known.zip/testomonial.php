
<section class="hero">
<img src="images/bg-pattern-top-desktop.svg" alt="" class="top" />
<!-- <div class="containerr row hero__row--modifier">
  <div class="hero__left-side">
    <h1 class="hero__header">10,000+ Of anjoman hefajoth members .</h1>
    <p class="hero__description">
      We Only Provide Great Products Combined With Excellent Customer
      Service .See What Our Satisfied Customers Are Saying About Our
      Services.
    </p>
  </div>
  <div class="hero__right-side">
    <div class="hero__reviews">
      <div class="hero__icons row">
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
      </div>
      <div class="review">
        <p>Related 5 Starts Reviews</p>
      </div>
    </div>
    <div class="hero__reviews">
      <div class="hero__icons row">
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
      </div>
      <div class="review">
        <p>Related 5 Starts In Report Guru</p>
      </div>
    </div>
    <div class="hero__reviews">
      <div class="hero__icons row">
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
        <img src="images/icon-star.svg" alt="" />
      </div>
      <div class="review">
        <p>Related Starts In BestTech</p>
      </div>
    </div>
  </div>
</div> -->
<!-- card start here  -->
<div class="hero__card">
  <div class="containerr row hero__card--row">
    <!-- card  -->
    <div class="card">
      <div class="card__header row">
        <!-- <img src="images/image-colton.jpg" alt="" class="card__image" /> -->
        <div class="card__info">
          <!-- <h3 class="name">rasidur rahman bornobi</h3> -->
          <!-- <div class="designation">verified buyer</div> -->
        </div>
      </div>
      <blockquote class="card__description">
        <p>মতভেদ আর দলাদলী</p>  
        <p>পায়ের নিচে দেব ফেলি</p>  
        <p>মধুর তানে তান ধরিব</p>  
        <p>ইল্লাল্লাহর আযান</p> 
      </blockquote>
    </div>
    <!-- =======  -->
    <div class="card">
      <div class="card__header row">
        <!-- <img src="images/image-irene.jpg" alt="" class="card__image" /> -->
        <div class="card__info">
          <!-- <h3 class="name">Colton Smith</h3> -->
          <!-- <div class="designation">verified buyer</div> -->
        </div>
      </div>
      
      <blockquote class="card__description">    
        <p>পাগল হয়ে নামবো মোরা</p>  
        <p>করবো পাগল বিশ্বসেরা</p>  
        <p>জানাই দিবো জগৎটাকে</p>  
        <p>আমরা মুসলমান</p> 
      </blockquote>
    </div>
    <!-- ========  -->
    <!-- <div class="card"> -->
      <!-- <div class="card__header row"> -->
        <!-- <img src="images/image-anne.jpg" alt="" class="card__image" /> -->
        <!-- <div class="card__info"> -->
          <!-- <h3 class="name">Colton Smith</h3> -->
          <!-- <div class="designation">verified buyer</div> -->
        <!-- </div> -->
      <!-- </div> -->
      <!-- <p class="card__description"> -->
        <!-- " We Needed The Same Printed Designed As The One We Had Ordered As
        The One We Had Ordered A Week Prior.Not Only Did They Find The
        Original Order .But We Also Receives It In Time.Excellent!" -->
      <!-- </p> -->
    <!-- </div> -->
  </div>
</div>
<img src="images/bg-pattern-bottom-desktop.svg" alt="" class="bottom" />
</section>