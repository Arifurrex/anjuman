
<!-- ============================ -->
    <!-- footer section start from here  -->
    <!-- ============================ -->

    <footer>
      <section class="letstalk">
        <div class="letstalk-card flex-wrap">
          <div class="letstalk-card__descrip">
            <h3 class="letstalk__title">সদস্য হতে চান ? </h3>
            <p class="paragraph letstalk__paragraph">
              কুরআন সুন্নাহ , খেলাফতে রাশেদীন ও সলফে সালেহীনের আদর্শ অনুসারে  
              আঞ্জুমানের সকল কার্যক্রমে হবে  
            </p>
          </div>
          <a href="" class="btn letstalk--btn">সদস্য ফরম </a>
        </div>
      </section>
      <div class="container footer--container">
        <div class="footer-nav">
          <a href="/index.html" class="logo-image">
            <img src="images/Only Logo.bmp" alt="logo-light" />
          </a>
          <ul class="footer-nav-list">
            <li class="footer-nav-list-item">
              <a href="aboutus.php" class="nav-linkss white"
                >আমাদের প্রতিষ্ঠান</a
              >
            </li>
            <li class="footer-nav-list-item">
              <a href="/src/3-pages/locations.html" class="nav-linkss white"
                >আমাদের সম্পর্কে</a
              >
            </li>
            <li class="footer-nav-list-item">
              <a href="http://anjumanehefajoth.com/contact.php" class="nav-linkss white"
                >যোগাযোগ করুন</a
              >
            </li>
          </ul>
        </div>
        <div class="line"></div>
        <!-- footer-details -->
        <!-- <div class="footer-details">
          <div class="footer-details-location">
            <h class="bold opacity05">Alinessa Central Office</h>
            <p class="paragraph">243/A Chowghari</p>
            <p class="paragraph">Golapgonj Sylhet</p>
          </div>
          <div class="footer-details-contact">
            <p class="bold opacity05">Contact Us (Central Office)</p>
            <p class="paragraph">P : +88 01995890189</p>
            <p class="paragraph">M : arifurrex@gmail.com</p>
          </div>
          <div class="footer-details-social">
            <span class="social-icon social-icon-facebook"></span>
            <span class="social-icon social-icon-youtube"></span>
            <span class="social-icon social-icon-twitter"></span>
            <span class="social-icon social-icon-pinterest"></span>
            <span class="social-icon social-icon-insta"></span>
          </div>
        </div> -->
        <!-- footer-details end -->
      </div>
    </footer>

    <!-- ============================ -->
    <!-- footer section end from here  -->
    <!-- ============================ -->

<script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/countUp.js"></script>
    <script src="js/countUp-jquery.js"></script>
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/jquery.easypiechart.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/typed.min.js"></script>
    <script src="js/script.js"></script>
<script src="src/1-scripts/script.js"></script>
</body>
</html>
