<?php
session_start();
?>
<?php include "header.php"; ?>

<?php
   require_once "../includes/dbh.inc.php";
   $id=$_GET['id'];
   $que="SELECT * FROM members WHERE member_id='$id'";
   $resl=mysqli_query($conn,$que) or die("query failed");
   $row=mysqli_fetch_assoc($resl);
?>
  <div class="admin-content">        
  <div class="contact__form">    
        <form action="../includes/update-member.inc.php?id=<?= $row['member_id'] ?>" method="post" autocomplete="off" enctype="multipart/form-data">
             <div class="add-user-header">
                 <h4 class="admin-heading">Edit member</h4>
             </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="frist-name" name="first_name" value="<?= $row['first_name'] ?>"/>
          </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="last-name"  name="last_name" value="<?= $row['last_name'] ?>"/>
          </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="username"  name="username" value="<?=$row['username']?>"/>
          </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="father_name"  name="father_name" value="<?=$row['father_name']?>"/>
          </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="phone"  name="phone"value="<?=$row['phone']?>" />
          </div>
          <div class="from-control paragraph">
          <input type="text" placeholder="email"  name="email" value="<?=$row['email']?>" />
          </div>
          <div class="from-control paragraph">
            <select name="village_id" id="" required>
            <option selected value="" disabled>select village </option>
            <option selected value="<?=$row['vllage_id']?>"><?=$row['village_id']?> </option>
            <option value="1">golapginj</option>
            <option value="2">jokigonj</option>
            </select>
          </div>
          <div class="from-control paragraph">
            <select name="post_office_id" id="" required>
            <option selected value="" disabled>select post office </option>
            <option selected value="<?=$row['post_office_id']?>"><?=$row['post_office_id']?> </option>
            <option value="1">golapginj</option>
            <option value="2">jokigonj</option>
            </select>
          </div>
          <div class="from-control paragraph">
            <select name="upojella_id" id="" required>
            <option selected value="" disabled>select upojella </option>
            <option selected value="<?=$row['upojella_id']?>"><?=$row['upojella_id']?> </option>
            <option value="1">golapginj</option>
            <option value="2">jokigonj</option>
            </select>
          </div>
          <div class="from-control paragraph">
            <select name="district_id" id="" required>
            <option selected value="" disabled>select district </option>
            <option selected value="<?=$row['district_id']?>"><?=$row['district_id']?> </option>
            <option value="1">sylhet</option>
            <option value="2">dhaka</option>
            </select>
          </div>
          <div class="from-control paragraph">
            <select name="position" id="" required>
            <option selected value="" disabled>select position </option>
            <option selected value="<?=$row['position']?>"><?=$row['position']?> </option>
            <option value="1">main</option>
            <option value="2">submain</option>
            </select>
          </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="nid number"  name="nid" value="<?=$row['nid']?>" />
          </div>
          <div class="from-control paragraph">
            <input type="text" placeholder="blood_group"  name="blood_group_id" value="<?=$row['blood_group_id']?>"/>
          </div>
         
          <div class="from-control paragraph">
          <img src="../images/<?=$row['avater']?>" alt="">
            <input type="file" placeholder="profile image"  name="avater" />
          </div>
          <div class="from-control">
            <input type="submit" value="Update member" name="submit" class="btn" />
          </div>
        </form>
   </div>
                  <!--/Form -->
 
          
  </div>
<?php include "footer.php"; ?>

