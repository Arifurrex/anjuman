<?php
require_once "../includes/dbh.inc.php";
$id=$_GET['id'];
$query="DELETE FROM `members`
WHERE member_id='$id'";
mysqli_query($conn,$query) OR die('query failed');
header('location:http://anjumanehefajoth.com/admin/all-member.php?msg=sucessdele');