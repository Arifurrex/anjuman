<?php
if(isset($_POST['submit'])){
  $district_name=$_POST['district_name'];
 require_once '../includes/dbh.inc.php';
 require_once '../includes/funtcion.inc.php';
 if(emptyinputcategory($district_name) == !false ){
      header('location:http://anjumanehefajoth.com/admin/add-category.php?error=emptyinput');
      exit();
 }
  insedistrict($district_name,$conn);

}else{
  header('location:http://anjumanehefajoth.com/admin/add-category.php');
  exit();
}
 
